# Instant Rebreak (standalone)

Just the InstantRebreak module from Meteor Client, as its own Fabric mod.
Source: `systems/modules/player/InstantRebreak.java` from meteor-client (master, MC 26.3; ported to 1.21.11).

Licensed GPL-3.0 (same as Meteor Client). See LICENSE.

## Build
Requires JDK 21 or newer.

    ./gradlew build

The jar is in `build/libs/`. Targets Minecraft 1.21.11 with Fabric Loader 0.16+ (Fabric API not required).

## Use
Mine a block, then keep it targeted. When the block reappears in the same spot,
the mod resends the STOP_DESTROY_BLOCK packet so it breaks instantly.

Press **R** in game to toggle it on/off (rebind under Options > Controls > Key Binds > Instant Rebreak).

Config is created on first launch at `config/instant-rebreak.properties`:
- `enabled` - whether it starts on or off (R toggles it during play)
- `delay` - ticks between break attempts (0 = every tick)
- `only-pick` - only act while holding a pickaxe

## Differences from Meteor's version
- No Meteor GUI/module system, so no settings screen (config file instead). Toggle is the R key.
- No block overlay rendering.
- No server-side rotation option (it depended on Meteor's Rotations system).
