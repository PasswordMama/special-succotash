plugins {
    alias(libs.plugins.fabric.loom)
}

base {
    archivesName = "instant-rebreak"
    group = "instantrebreak"
    version = "${libs.versions.minecraft.get()}-${providers.gradleProperty("mod_version").get()}"
}

repositories {
    mavenCentral()
}

dependencies {
    minecraft(libs.minecraft)
    mappings(loom.officialMojangMappings())
    modImplementation(libs.fabric.loader)
}

// Minecraft 1.21.11 runs on Java 21 (what Zalith uses)
tasks.withType<JavaCompile>().configureEach {
    options.release = 21
}

loom {
    accessWidenerPath = file("src/main/resources/instant-rebreak.accesswidener")
}

tasks.processResources {
    val props = mapOf("version" to project.version)
    inputs.properties(props)
    filesMatching("fabric.mod.json") { expand(props) }
}
