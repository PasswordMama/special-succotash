/*
 * Derived from Meteor Client's InstantRebreak module
 * (https://github.com/MeteorDevelopment/meteor-client)
 * Copyright (c) Meteor Development. Licensed under GPL-3.0.
 */

package instantrebreak;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.Shapes;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class InstantRebreak implements ClientModInitializer {
    private static final Minecraft mc = Minecraft.getInstance();

    // Toggle key (default R, rebindable in Options > Controls > Key Binds)
    private static final KeyMapping.Category CATEGORY =
        KeyMapping.Category.register(Identifier.fromNamespaceAndPath("instant-rebreak", "instant-rebreak"));
    public static final KeyMapping TOGGLE_KEY =
        new KeyMapping("key.instant-rebreak.toggle", InputConstants.Type.KEYSYM, InputConstants.KEY_R, CATEGORY);

    // Config (config/instant-rebreak.properties)
    private static boolean enabled = true;
    private static int tickDelay = 0;
    private static boolean onlyPick = true;

    private static final BlockPos.MutableBlockPos blockPos = new BlockPos.MutableBlockPos(0, Integer.MIN_VALUE, 0);
    private static Direction direction;
    private static int ticks;

    @Override
    public void onInitializeClient() {
        loadConfig();
    }

    /** Called from the mixin when the player starts breaking a block. */
    public static void onStartBreaking(BlockPos pos, Direction dir) {
        direction = dir;
        blockPos.set(pos);
    }

    public static void onTick() {
        // Toggle with the key (only when no screen is open, so typing in chat doesn't trigger it)
        while (TOGGLE_KEY.consumeClick()) {
            if (mc.screen != null) continue;
            enabled = !enabled;
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal("[Instant Rebreak] " + (enabled ? "ON" : "OFF")), false);
            }
        }

        if (!enabled || mc.player == null || mc.level == null || mc.gameMode == null || mc.getConnection() == null) return;

        if (ticks >= tickDelay) {
            ticks = 0;

            if (shouldMine()) {
                sendPacket();
                mc.player.swing(InteractionHand.MAIN_HAND);
            }
        } else {
            ticks++;
        }
    }

    private static void sendPacket() {
        BlockPos pos = blockPos.immutable();
        Direction dir = direction == null ? Direction.UP : direction;

        mc.gameMode.startPrediction(mc.level, sequence ->
            new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.STOP_DESTROY_BLOCK, pos, dir, sequence)
        );
    }

    private static boolean shouldMine() {
        if (mc.level.isOutsideBuildHeight(blockPos) || !canBreak(blockPos)) return false;

        return !onlyPick || mc.player.getMainHandItem().is(ItemTags.PICKAXES);
    }

    // Same check as Meteor's BlockUtils.canBreak
    private static boolean canBreak(BlockPos pos) {
        BlockState state = mc.level.getBlockState(pos);
        if (!mc.player.isCreative() && state.getDestroySpeed(mc.level, pos) < 0) return false;
        return state.getShape(mc.level, pos) != Shapes.empty();
    }

    // Config

    private static void loadConfig() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("instant-rebreak.properties");
        Properties props = new Properties();

        if (Files.exists(path)) {
            try (InputStream in = Files.newInputStream(path)) {
                props.load(in);
            } catch (IOException ignored) {}
        }

        enabled = Boolean.parseBoolean(props.getProperty("enabled", "true"));
        onlyPick = Boolean.parseBoolean(props.getProperty("only-pick", "true"));
        try {
            tickDelay = Math.max(0, Integer.parseInt(props.getProperty("delay", "0")));
        } catch (NumberFormatException e) {
            tickDelay = 0;
        }

        props.setProperty("enabled", Boolean.toString(enabled));
        props.setProperty("only-pick", Boolean.toString(onlyPick));
        props.setProperty("delay", Integer.toString(tickDelay));

        try (OutputStream out = Files.newOutputStream(path)) {
            props.store(out, "Instant Rebreak - enabled, delay (ticks between attempts), only-pick (require pickaxe in hand)");
        } catch (IOException ignored) {}
    }
}
