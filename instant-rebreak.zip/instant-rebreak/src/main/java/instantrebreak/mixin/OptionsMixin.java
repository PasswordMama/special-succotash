/*
 * Derived from Meteor Client (https://github.com/MeteorDevelopment/meteor-client)
 * Copyright (c) Meteor Development. Licensed under GPL-3.0.
 */

package instantrebreak.mixin;

import instantrebreak.InstantRebreak;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;

@Mixin(Options.class)
public abstract class OptionsMixin {
    @Shadow
    @Final
    @Mutable
    public KeyMapping[] keyMappings;

    // Adds the toggle key to the vanilla Controls screen (rebindable there)
    @Inject(method = "<init>", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Options;keyMappings:[Lnet/minecraft/client/KeyMapping;", opcode = Opcodes.PUTFIELD, shift = At.Shift.AFTER))
    private void instantrebreak$addKeys(Minecraft minecraft, File workingDirectory, CallbackInfo ci) {
        KeyMapping[] newKeys = new KeyMapping[keyMappings.length + 1];
        System.arraycopy(keyMappings, 0, newKeys, 0, keyMappings.length);
        newKeys[keyMappings.length] = InstantRebreak.TOGGLE_KEY;
        keyMappings = newKeys;
    }
}
