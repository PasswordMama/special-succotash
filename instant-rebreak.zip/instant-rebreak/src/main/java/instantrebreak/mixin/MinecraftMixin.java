/*
 * Derived from Meteor Client (https://github.com/MeteorDevelopment/meteor-client)
 * Copyright (c) Meteor Development. Licensed under GPL-3.0.
 */

package instantrebreak.mixin;

import instantrebreak.InstantRebreak;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    // Runs at the start of every client tick (replaces the Fabric API tick event)
    @Inject(method = "tick", at = @At("HEAD"))
    private void instantrebreak$onTick(CallbackInfo ci) {
        InstantRebreak.onTick();
    }
}
